#include "Board.h"

// Some ready-made 16-bit ('565') color settings:
#define ST77XX_BLACK 0x0000
#define ST77XX_WHITE 0xFFFF
#define ST77XX_RED 0xF800
#define ST77XX_GREEN 0x07E0
#define ST77XX_BLUE 0x001F
#define ST77XX_CYAN 0x07FF
#define ST77XX_MAGENTA 0xF81F
#define ST77XX_YELLOW 0xFFE0
#define ST77XX_ORANGE 0xFC00

#define SPI_CS  IOID_20
#define IC_RST IOID_13
#define SPI_RS  IOID_9
#define SPI_SDA IOID_14
#define SPI_SCK IOID_10
#define LED_RED IOID_6
#define LED_GREEN IOID_7

/* Pin driver handle */
static PIN_Handle PinHandle;
static PIN_State PinState;
unsigned char Data_BUS;
PIN_Config PinTable[] = {

                         SPI_CS       | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
                         IC_RST       | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
                         SPI_RS       | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
                         SPI_SDA      | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
                         SPI_SCK      | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
                         LED_RED      | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
                         LED_GREEN    | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    PIN_TERMINATE
};

unsigned char GATE,SOURCE;

void delay(unsigned int delay_value)
{
    while(delay_value!=0)
    delay_value--;
}

void delay1(unsigned int delay_value)
{
    unsigned int i,j;

    for(i=0;i<=delay_value;i++)
    {
        for(j=0;j<=delay_value;j++)
        {}
    }
}

void initTftPin()
{
    PinHandle = PIN_open(&PinState, PinTable);
}

void Write_byte(unsigned char dat)
{
    unsigned char i;

    for(i=0;i<8;i++)
    {
        if((dat<<i)&0x80)
        {
            PIN_setOutputValue(PinHandle, SPI_SDA,1);
        }
        else
        {
            PIN_setOutputValue(PinHandle, SPI_SDA,0);
        }
        delay1(5);
        PIN_setOutputValue(PinHandle, SPI_SCK,0);
        delay1(2);
        PIN_setOutputValue(PinHandle, SPI_SCK,1);
    }
}

void Write_Command(unsigned char command)
{
    PIN_setOutputValue(PinHandle, SPI_SCK,1);
    PIN_setOutputValue(PinHandle, SPI_RS,0);
    PIN_setOutputValue(PinHandle, SPI_SDA,0);
    PIN_setOutputValue(PinHandle, SPI_CS,0);
    Write_byte(command);
    PIN_setOutputValue(PinHandle, SPI_CS,1);
    PIN_setOutputValue(PinHandle, SPI_SDA,1);
}

void Write_Data(unsigned char data1)
{
    PIN_setOutputValue(PinHandle, SPI_SCK,1);
    PIN_setOutputValue(PinHandle, SPI_RS,1);
    PIN_setOutputValue(PinHandle, SPI_SDA,0);
    PIN_setOutputValue(PinHandle, SPI_CS,0);
    Write_byte(data1);
    PIN_setOutputValue(PinHandle, SPI_CS,1);
    PIN_setOutputValue(PinHandle, SPI_SDA,1);
}

void Write_Data16(unsigned int data1)
{
    PIN_setOutputValue(PinHandle, SPI_SCK,1);
    PIN_setOutputValue(PinHandle, SPI_RS,1);
    PIN_setOutputValue(PinHandle, SPI_SDA,0);
    PIN_setOutputValue(PinHandle, SPI_CS,0);
    Write_byte(data1);
    PIN_setOutputValue(PinHandle, SPI_CS,1);
    PIN_setOutputValue(PinHandle, SPI_SDA,1);
}



/////////3-SPI initial///////////////////////////
ST7735S_WF18F(void)
{
    GATE = 161;
        SOURCE = 255;

    PIN_setOutputValue(PinHandle, SPI_CS,0);
    PIN_setOutputValue(PinHandle, SPI_RS,1);
    PIN_setOutputValue(PinHandle, IC_RST,1);


    delay(1000);
    asm(" nop");
    asm(" nop");
    asm(" nop");
    PIN_setOutputValue(PinHandle, IC_RST,0);
    delay(100);
    PIN_setOutputValue(PinHandle, IC_RST,1);
    asm(" nop");
    asm(" nop");
    asm(" nop");
    delay(500);

    Write_Command(0x11);    //Sleep out
    delay(150);             //Delay 120ms

    Write_Command(0x3A);    //65K Mode
    Write_Data(0x05);

    Write_Command(0x36);
    Write_Data(0x08);

    //ST7789S Frame rate setting
    Write_Command(0xB1); //Frame Rate Control (In normal mode/ Full colors)
    Write_Data(0x05);
    Write_Data(0x3A);
    Write_Data(0x3A);

    Write_Command(0xB2); //Frame Rate Control (In Idle mode/ 8-colors)
    Write_Data(0x05);
    Write_Data(0x3A);
    Write_Data(0x3A);

    Write_Command(0xB3); //Frame Rate Control (In Partial mode/ full colors)
    Write_Data(0x05);
    Write_Data(0x3A);
    Write_Data(0x3A);
    Write_Data(0x05);
    Write_Data(0x3A);
    Write_Data(0x3A);

    Write_Command(0xB4); //Dot Inversion
    Write_Data(0x03);

    //ST7789S Power setting
    Write_Command(0xC0);    //Power Control 1
    Write_Data(0x62);
    Write_Data(0x02);
    Write_Data(0x04);

    Write_Command(0xC1);    //Power Control 2
    Write_Data(0xC0);

    Write_Command(0xC2);    //Power Control 3 (in Normal mode/ Full colors)
    Write_Data(0x0D);
    Write_Data(0x00);

    Write_Command(0xC3);    //Power Control 4 (in Idle mode/ 8-colors)
    Write_Data(0x8D);
    Write_Data(0x6A);

    Write_Command(0xC4);    //Power Control 5 (in Partial mode/ full-colors)
    Write_Data(0x8D);
    Write_Data(0xEE);

    Write_Command(0xC5);    //VCOM Control 1
    Write_Data(0x12);

    //ST7789S Gamma Setting
    Write_Command(0xE0); //Gamma (��+��polarity) Correction Characteristics Setting
    Write_Data(0x03);
    Write_Data(0x1B);
    Write_Data(0x12);
    Write_Data(0x11);
    Write_Data(0x3F);
    Write_Data(0x3A);
    Write_Data(0x32);
    Write_Data(0x34);
    Write_Data(0x2F);
    Write_Data(0x2B);
    Write_Data(0x30);
    Write_Data(0x3A);
    Write_Data(0x00);
    Write_Data(0x01);
    Write_Data(0x02);
    Write_Data(0x05);

    Write_Command(0xE1); //Gamma ��-��polarity Correction Characteristics Setting
    Write_Data(0x03);
    Write_Data(0x1B);
    Write_Data(0x12);
    Write_Data(0x11);
    Write_Data(0x32);
    Write_Data(0x2F);
    Write_Data(0x2A);
    Write_Data(0x2F);
    Write_Data(0x2E);
    Write_Data(0x2C);
    Write_Data(0x35);
    Write_Data(0x3F);
    Write_Data(0x00);
    Write_Data(0x00);
    Write_Data(0x01);
    Write_Data(0x05);

    Write_Command(0xFC); //Enable Gate power save mode
    Write_Data(0x8C);

    Write_Command(0x2A); //Column Address Set
    Write_Data(0x00);
    Write_Data(0x00);//0
    Write_Data(0x00);
    Write_Data(0x7F);//127

    Write_Command(0x2B); //Row Address Set
    Write_Data(0x00);
    Write_Data(0x00);//0
    Write_Data(0x00);
    Write_Data(0x9F);//159

    Write_Command(0x29); //Display on
}

void FULL_ON(unsigned int data1)
{
    unsigned int x,y;

    Write_Command(0x2c);
    for(x=0;x<SOURCE;x++)
    {
        for(y=0;y<GATE;y++)
        {
            Write_Data16(data1);
        }
    }
}
