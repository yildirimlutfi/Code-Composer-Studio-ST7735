#include <ST7735.h>

uint32_t x=0;

int main(void)
{
    Board_init();

    initTftPin();

    ST7735S_WF18F();


    while(1)
    {
        FULL_ON(x++);
    }

}
