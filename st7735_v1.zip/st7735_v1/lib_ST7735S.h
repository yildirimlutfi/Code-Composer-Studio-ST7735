
#include "Board.h"
#include <ti/drivers/PIN.h>
#include <ti/drivers/pin/PINCC26XX.h>
#include <ti/drivers/GPIO.h>

#define SPI_CS  IOID_20
#define SPI_RST IOID_13
#define SPI_RS  IOID_9
#define SPI_SDA IOID_14
#define SPI_SCK IOID_10
#define LED_RED IOID_6
#define LED_GREEN IOID_7

/* Pin driver handle */
static PIN_Handle PinHandle;
static PIN_State PinState;

PIN_Config PinTable[] = {

                               SPI_CS       | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
                               SPI_RST      | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
                               SPI_RS       | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
                               SPI_SDA      | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
                               SPI_SCK      | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
                               LED_RED      | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
                               LED_GREEN    | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    PIN_TERMINATE
};

unsigned char GATE,SOURCE;

void delay(unsigned int delay_value)
{
    while(delay_value!=0)
    delay_value--;
}

void delay1(unsigned int delay_value)
{
    unsigned int i,j;

    for(i=0;i<=delay_value;i++)
    {
        for(j=0;j<=delay_value;j++)
        {}
    }
}

void initTftPin()
{
    PinHandle = PIN_open(&PinState, PinTable);
}



//SPI
void Write_byte(unsigned char dat)
{
    unsigned char i;

    for(i=0;i<8;i++)
    {
        if((dat<<i)&0x80)
        {
            PIN_setOutputValue(PinHandle, SPI_SDA,1);
        }
        else
        {
            PIN_setOutputValue(PinHandle, SPI_SDA,0);
        }
        delay1(5);
        PIN_setOutputValue(PinHandle, SPI_SCK,0);
        delay1(2);
        PIN_setOutputValue(PinHandle, SPI_SCK,1);
    }
}

//SPI ST7735S USE_2017_08_30 NewADD
void SPI_ST7735S_WrCmd(unsigned char dat)
{
    PIN_setOutputValue(PinHandle, SPI_CS,0);
    PIN_setOutputValue(PinHandle, SPI_SDA,0);
    PIN_setOutputValue(PinHandle, SPI_SCK,0);
    PIN_setOutputValue(PinHandle, SPI_SCK,1);

    delay1(5);
    Write_byte(dat);
    delay1(5);
    PIN_setOutputValue(PinHandle, SPI_CS,1);
}


//SPI ST7735S USE_2017_08_30 NewADD
void SPI_ST7735S_WriteData(unsigned char dat)
{
    PIN_setOutputValue(PinHandle, SPI_RS,1);
    PIN_setOutputValue(PinHandle, SPI_CS,0);
    PIN_setOutputValue(PinHandle, SPI_SDA,1);
    PIN_setOutputValue(PinHandle, SPI_SCK,0);
    PIN_setOutputValue(PinHandle, SPI_SCK,1);
    delay1(5);
    Write_byte(dat);
    delay1(5);
    PIN_setOutputValue(PinHandle, SPI_CS,1);
    PIN_setOutputValue(PinHandle, SPI_RS,0);
    PIN_setOutputValue(PinHandle, LED_RED,!PIN_getOutputValue(LED_RED));

}


/////////3-SPI initial///////////////////////////
void ST7735S_128x160(void)  //128x160
{
    GATE = 160;
    SOURCE = 128;
    PIN_setOutputValue(PinHandle, SPI_CS,0);
    PIN_setOutputValue(PinHandle, SPI_RS,1);
    PIN_setOutputValue(PinHandle, SPI_RST,1);
    delay(1000);
    asm(" nop");
    asm(" nop");
    asm(" nop");
    PIN_setOutputValue(PinHandle, SPI_RST,0);
    delay(100);
    PIN_setOutputValue(PinHandle, SPI_RST,1);
    asm(" nop");
    asm(" nop");
    asm(" nop");
    delay(500);

    SPI_ST7735S_WrCmd(0x11);    //Sleep out
    delay(150);             //Delay 120ms

    SPI_ST7735S_WrCmd(0x3A);    //05: 65K (16 bit) 06: 262K (8 bit)
    SPI_ST7735S_WriteData(0x05);

    SPI_ST7735S_WrCmd(0x36);
    SPI_ST7735S_WriteData(0x08);

    //ST7735S Frame rate setting
    SPI_ST7735S_WrCmd(0xB1); //Frame Rate Control (In normal mode/ Full colors)
    SPI_ST7735S_WriteData(0x05);
    SPI_ST7735S_WriteData(0x3A);
    SPI_ST7735S_WriteData(0x3A);

    SPI_ST7735S_WrCmd(0xB2); //Frame Rate Control (In Idle mode/ 8-colors)
    SPI_ST7735S_WriteData(0x05);
    SPI_ST7735S_WriteData(0x3A);
    SPI_ST7735S_WriteData(0x3A);

    SPI_ST7735S_WrCmd(0xB3); //Frame Rate Control (In Partial mode/ full colors)
    SPI_ST7735S_WriteData(0x05);
    SPI_ST7735S_WriteData(0x3A);
    SPI_ST7735S_WriteData(0x3A);
    SPI_ST7735S_WriteData(0x05);
    SPI_ST7735S_WriteData(0x3A);
    SPI_ST7735S_WriteData(0x3A);

    SPI_ST7735S_WrCmd(0xB4); //Dot Inversion
    SPI_ST7735S_WriteData(0x03);

    //ST7735S Power setting
    SPI_ST7735S_WrCmd(0xC0);    //Power Control 1
    SPI_ST7735S_WriteData(0x62);
    SPI_ST7735S_WriteData(0x02);
    SPI_ST7735S_WriteData(0x04);

    SPI_ST7735S_WrCmd(0xC1);    //Power Control 2
    SPI_ST7735S_WriteData(0xC0);

    SPI_ST7735S_WrCmd(0xC2);    //Power Control 3 (in Normal mode/ Full colors)
    SPI_ST7735S_WriteData(0x0D);
    SPI_ST7735S_WriteData(0x00);

    SPI_ST7735S_WrCmd(0xC3);    //Power Control 4 (in Idle mode/ 8-colors)
    SPI_ST7735S_WriteData(0x8D);
    SPI_ST7735S_WriteData(0x6A);

    SPI_ST7735S_WrCmd(0xC4);    //Power Control 5 (in Partial mode/ full-colors)
    SPI_ST7735S_WriteData(0x8D);
    SPI_ST7735S_WriteData(0xEE);

    SPI_ST7735S_WrCmd(0xC5);    //VCOM Control 1
    SPI_ST7735S_WriteData(0x12);

    //ST7735S Gamma Setting
    SPI_ST7735S_WrCmd(0xE0); //Gamma (��+��polarity) Correction Characteristics Setting
    SPI_ST7735S_WriteData(0x03);
    SPI_ST7735S_WriteData(0x1B);
    SPI_ST7735S_WriteData(0x12);
    SPI_ST7735S_WriteData(0x11);
    SPI_ST7735S_WriteData(0x3F);
    SPI_ST7735S_WriteData(0x3A);
    SPI_ST7735S_WriteData(0x32);
    SPI_ST7735S_WriteData(0x34);
    SPI_ST7735S_WriteData(0x2F);
    SPI_ST7735S_WriteData(0x2B);
    SPI_ST7735S_WriteData(0x30);
    SPI_ST7735S_WriteData(0x3A);
    SPI_ST7735S_WriteData(0x00);
    SPI_ST7735S_WriteData(0x01);
    SPI_ST7735S_WriteData(0x02);
    SPI_ST7735S_WriteData(0x05);

    SPI_ST7735S_WrCmd(0xE1); //Gamma ��-��polarity Correction Characteristics Setting
    SPI_ST7735S_WriteData(0x03);
    SPI_ST7735S_WriteData(0x1B);
    SPI_ST7735S_WriteData(0x12);
    SPI_ST7735S_WriteData(0x11);
    SPI_ST7735S_WriteData(0x32);
    SPI_ST7735S_WriteData(0x2F);
    SPI_ST7735S_WriteData(0x2A);
    SPI_ST7735S_WriteData(0x2F);
    SPI_ST7735S_WriteData(0x2E);
    SPI_ST7735S_WriteData(0x2C);
    SPI_ST7735S_WriteData(0x35);
    SPI_ST7735S_WriteData(0x3F);
    SPI_ST7735S_WriteData(0x00);
    SPI_ST7735S_WriteData(0x00);
    SPI_ST7735S_WriteData(0x01);
    SPI_ST7735S_WriteData(0x05);

    SPI_ST7735S_WrCmd(0xFC); //Enable Gate power save mode
    SPI_ST7735S_WriteData(0x8C);

    SPI_ST7735S_WrCmd(0x2A); //Column Address Set
    SPI_ST7735S_WriteData(0x00);
    SPI_ST7735S_WriteData(0x00);//02 : old FPC | 00 : New FPC
    SPI_ST7735S_WriteData(0x00);//             |
    SPI_ST7735S_WriteData(0x7F);//129 : old FPC| 128 : New FPC

    SPI_ST7735S_WrCmd(0x2B); //Row Address Set
    SPI_ST7735S_WriteData(0x00);
    SPI_ST7735S_WriteData(0x00);//01 : Old  | 00 : New FPC
    SPI_ST7735S_WriteData(0x00);//          |
    SPI_ST7735S_WriteData(0x9F);//160 : Old | 159 : New FPC

    SPI_ST7735S_WrCmd(0x29); //Display on
    SPI_ST7735S_WrCmd(0x2C); //GRAM
}

///////////////////////////////////////////////////////////
void FULL_ON_SPI(unsigned int data1)
{
    unsigned int x,y;

    for(x=0;x<SOURCE;x++)
    {
        for(y= 0;y<GATE;y++)
        {
            SPI_ST7735S_WriteData(data1>>8);
            SPI_ST7735S_WriteData(data1);
        }
        PIN_setOutputValue(PinHandle, LED_GREEN,!PIN_getOutputValue(LED_GREEN));
    }
}
