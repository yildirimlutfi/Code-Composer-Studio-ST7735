

#include <ST7735.h>
#include <ti/drivers/rf/RF.h>
#include <ti/drivers/pin/PINCC26XX.h>
#include <ti/drivers/Board.h>
#include <ti/drivers/PIN.h>
#include <ti/drivers/GPIO.h>

#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Task.h>
#include <xdc/runtime/Error.h>




int main(void)
{
    Board_initGeneral();
    initTftPin();

//lib_ST7735S_16bit.h
    ST7735S_WF18F();
    while(1)
    {
        FULL_ON(0x11);
        FULL_ON(0x33);
        FULL_ON(0x55);
    }

}
