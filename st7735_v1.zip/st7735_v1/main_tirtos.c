

#include <ti/drivers/rf/RF.h>
#include <ti/drivers/pin/PINCC26XX.h>
#include <ti/drivers/Board.h>
#include <ti/drivers/PIN.h>
#include <ti/drivers/GPIO.h>

#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Task.h>
#include <xdc/runtime/Error.h>

//#define serial

#ifdef serial
#include <lib_ST7735S.h>
#else
#include <lib_ST7735S_16bit.h>
#endif

int main(void)
{
    Board_initGeneral();
    initTftPin();
#ifdef serial
//    lib_ST7735S.h
        ST7735S_128x160();
        while(1)
        {
            FULL_ON_SPI(0xF800); //red

            FULL_ON_SPI(0x07E0); //green

            FULL_ON_SPI(0x003F); //blue

            FULL_ON_SPI(0x0000); //black

            FULL_ON_SPI(0xFFFF); //white
        }


#else
//lib_ST7735S_16bit.h
    ST7735S_WF18F();
    while(1)
    {
        FULL_ON(0xF000);//red

        FULL_ON(0x07E0);//green

        FULL_ON(0x001F);//blue

        FULL_ON(0x0000);//black

        FULL_ON(0xFFFF);//white

    }

#endif
}
